<!DOCTYPE html>
<html lang="en">
    <?php   
        include './header.php';
    ?>
<body>
    <div class="wrapper">
        <?php   
            include './navbar.php'; 
            include './content-blank.php';
        ?>
    </div> 
    <script src="js/app.js"></script>
</body>
</html>